# UnityHexapodSimulator
Hexapod robot prototyping using Unity,
the actual robot built following this experiment is open sourced here:
https://github.com/etienne-p/ArduinoHexapod
